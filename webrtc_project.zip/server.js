const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// ملفات ثابتة من مجلد public
app.use(express.static(path.join(__dirname, "public")));

// مسارات الصفحات
app.get("/sender", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "sender.html"));
});

app.get("/viewer", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "viewer.html"));
});

io.on("connection", (socket) => {
  console.log("📡 متصل:", socket.id);

  socket.on("join", ({ room, role }) => {
    socket.join(room);
    socket.data.room = room;
    socket.data.role = role;
    console.log(`🔹 ${socket.id} دخل ${room} كـ ${role}`);

    if (role === "viewer") {
      socket.to(room).emit("viewer-joined", { viewerId: socket.id });
    }
  });

  socket.on("offer", ({ to, sdp }) => {
    io.to(to).emit("offer", { from: socket.id, sdp });
  });

  socket.on("answer", ({ to, sdp }) => {
    io.to(to).emit("answer", { from: socket.id, sdp });
  });

  socket.on("ice-candidate", ({ to, candidate }) => {
    io.to(to).emit("ice-candidate", { from: socket.id, candidate });
  });

  socket.on("disconnect", () => {
    const room = socket.data.room;
    if (room) {
      socket.to(room).emit("peer-disconnected", { id: socket.id });
    }
    console.log(`❌ قطع الاتصال: ${socket.id}`);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 السيرفر يعمل على: http://localhost:${PORT}`);
});
