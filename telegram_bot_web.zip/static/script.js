
const loginForm = document.getElementById("loginForm");
const verifyForm = document.getElementById("verifyForm");
const startBotBtn = document.getElementById("startBot");

loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const api_id = document.getElementById("api_id").value;
    const api_hash = document.getElementById("api_hash").value;
    const phone = document.getElementById("phone").value;

    const res = await fetch("/send_code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ api_id, api_hash, phone })
    });
    const data = await res.json();
    if (data.status === "ok") {
        loginForm.style.display = "none";
        verifyForm.style.display = "block";
        window.phoneNumber = phone;
        alert("✅ تم إرسال كود التفعيل إلى رقمك");
    }
});

verifyForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const code = document.getElementById("code").value;
    const res = await fetch("/verify_code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: window.phoneNumber, code })
    });
    const data = await res.json();
    if (data.status === "success") {
        alert("✅ تم تسجيل الدخول بنجاح، يمكنك الآن إضافة المجموعات");
        verifyForm.style.display = "none";
    } else {
        alert("❌ حدث خطأ في التحقق من الكود");
    }
});

startBotBtn.addEventListener("click", async () => {
    const groups = document.getElementById("groups").value;
    const res = await fetch("/start_bot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: window.phoneNumber, groups })
    });
    const data = await res.json();
    if (data.status === "started") {
        alert("🚀 بدأ البوت بإرسال الإعلانات!");
    } else {
        alert("❌ حدث خطأ");
    }
});
